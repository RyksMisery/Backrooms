extends Node3D

const ROOM_SIZE = 10
const GRID_SIZE = 10

var grid = []
var wall_material: StandardMaterial3D
var floor_material: StandardMaterial3D

func _ready():
	_load_materials()
	_generate_maze()
	_build_level()
	_spawn_player()
	print("Уровень создан. Детей: ", get_child_count())

func _load_materials():
	ceiling_material = StandardMaterial3D.new()
	ceiling_material.albedo_texture = load("res://textures/ceiling.png")
	ceiling_material.uv1_triplanar = true
	ceiling_material.uv1_scale = Vector3(0.2, 0.2, 0.2)
	
	wall_material = StandardMaterial3D.new()
	wall_material.albedo_texture = load("res://textures/wall.png")
	wall_material.uv1_triplanar = true
	wall_material.uv1_scale = Vector3(0.2, 0.2, 0.2)
	
	floor_material = StandardMaterial3D.new()
	floor_material.albedo_texture = load("res://textures/floor.png")
	floor_material.uv1_triplanar = true
	floor_material.uv1_scale = Vector3(0.2, 0.2, 0.2)

func _generate_maze():
	for x in range(GRID_SIZE):
		grid.append([])
		for z in range(GRID_SIZE):
			grid[x].append(1)
	_carve_path(1, 1)
	grid[1][1] = 0
	grid[GRID_SIZE-2][GRID_SIZE-2] = 0

func _carve_path(x, z):
	var directions = [[0,2],[0,-2],[2,0],[-2,0]]
	directions.shuffle()
	for dir in directions:
		var nx = x + dir[0]
		var nz = z + dir[1]
		if nx > 0 and nx < GRID_SIZE-1 and nz > 0 and nz < GRID_SIZE-1:
			if grid[nx][nz] == 1:
				grid[nx][nz] = 0
				grid[x + dir[0]/2][z + dir[1]/2] = 0
				_carve_path(nx, nz)

func _build_level():
	for x in range(GRID_SIZE):
		for z in range(GRID_SIZE):
			var pos = Vector3(x * ROOM_SIZE, 0, z * ROOM_SIZE)
			if grid[x][z] == 0:
				_build_room(pos)
			else:
				_build_wall_block(pos)

func _build_room(pos: Vector3):
	var floor_box = CSGBox3D.new()
	floor_box.size = Vector3(ROOM_SIZE, 0.2, ROOM_SIZE)
	floor_box.position = pos
	floor_box.use_collision = true
	floor_box.material_override = floor_material
	add_child(floor_box)
	
	var ceiling_box = CSGBox3D.new()
	ceiling_box.size = Vector3(ROOM_SIZE, 0.2, ROOM_SIZE)
	ceiling_box.position = pos + Vector3(0, 4, 0)
	ceiling_box.use_collision = true
	ceiling_box.material_override = ceiling_material
	add_child(ceiling_box)
	
	var lamp = OmniLight3D.new()
	lamp.position = pos + Vector3(0, 3.8, 0)
	lamp.light_color = Color(1.0, 0.94, 0.78)
	lamp.light_energy = 2.5
	lamp.omni_range = 12
	add_child(lamp)

func _build_wall_block(pos: Vector3):
	var wall_box = CSGBox3D.new()
	wall_box.size = Vector3(ROOM_SIZE, 4.2, ROOM_SIZE)
	wall_box.position = pos + Vector3(0, 2, 0)
	wall_box.use_collision = true
	wall_box.material_override = wall_material
	add_child(wall_box)

func _spawn_player():
	var player_scene = preload("res://player.tscn")
	var player = player_scene.instantiate()
	player.position = Vector3(ROOM_SIZE, 1.5, ROOM_SIZE)
	add_child(player)
	print("Игрок создан на позиции: ", player.position)
	print("Камера: ", player.get_node_or_null("Camera3D"))
