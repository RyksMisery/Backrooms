extends CharacterBody3D

const SPEED = 5.0
var mouse_sensitivity = 0.003
var camera: Camera3D

func _ready():
	await get_tree().process_frame
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	camera = get_node_or_null("Camera3D")
	if camera == null:
		for child in get_children():
			if child is Camera3D:
				camera = child
				break

func _input(event):
	if camera == null:
		return
	if event is InputEventMouseMotion:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, -1.2, 1.2)
	if event.is_action_pressed("ui_cancel"):
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

func _physics_process(delta):
	if not is_on_floor():
		velocity.y -= 9.8 * delta

	var direction = Vector3.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_action_pressed("ui_up"):
		direction -= transform.basis.z
	if Input.is_key_pressed(KEY_S) or Input.is_action_pressed("ui_down"):
		direction += transform.basis.z
	if Input.is_key_pressed(KEY_A) or Input.is_action_pressed("ui_left"):
		direction -= transform.basis.x
	if Input.is_key_pressed(KEY_D) or Input.is_action_pressed("ui_right"):
		direction += transform.basis.x

	direction = direction.normalized()
	velocity.x = direction.x * SPEED
	velocity.z = direction.z * SPEED
	move_and_slide()
